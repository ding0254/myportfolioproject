What you need to know before using portfolio manager:
You may generate a database for EF
When you first start form, please click "sample" first to initiate base data in database;
Owing to foreingh keys, deleting or updating rate and instrument may be not allowed;
To refresh trade list, please click "refresh trades from database";
To get simulation, please click "Price book using simulation".

